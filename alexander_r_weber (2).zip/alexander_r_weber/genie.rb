class Genie

	attr_accessor :name
	attr_reader :age

	def initialize(name, age)
		p "Initializing Genie..."
		@name = name
		@age = age
		@invisible = false
		@submitted_wishes = {}
	end

	def appear
		p "*POOF!* I am #{name}, and you have three wishes!"
	end

	def grant_wish(wish)
		if @submitted_wishes.length < 3
			p "Your wish of '#{wish}' has been granted!"
			granted = true
			@submitted_wishes[wish] = granted
		else
			p "Sorry, I've already granted three wishes today."
			granted = false
			@submitted_wishes[wish] = granted
		end
	end
	

	def display_wish_history
		# I had trouble here trying to get my output to equal false when the wish was false in the hash. I'm missing something, but not sure what.
		# I had to move on due to time constraints.
		
		@submitted_wishes.each do |wish, granted|
			if granted = true
				p "#{wish} was granted!"
			elsif granted = false
				p "#{wish} was not granted."
			end
			
		end
	end
	
	def invisible
		p "I think I'll go invisible today!"
		@invisible = true
	end
		

	# Method to detect words in wish history with the most vowels, and 
	# print said word or words.
		# Input: All (wish's)
		# Steps: 
			# Put all wish's into array
			# Split array by words
				# Examine each word for number of vowels \aeiou\.
			# Create new hash. Key is word, value is number of vowels
			# Print key(s) with highest value
		# Output: String of key(s) with highest value


end

aladin = Genie.new("Aladin", 2602)
p aladin

aladin.appear
aladin.grant_wish("I want a million dollars")
aladin.grant_wish("I want a Lambo!")
aladin.grant_wish("I want world peace!")
aladin.grant_wish("I want lots of gold")
aladin.grant_wish("I want my own genie forever")
p aladin 

p aladin.display_wish_history

aladin.invisible
p aladin



# I left the below user input (question 9) work in, even though
# it doesn't work once it gets to the while loop. I was just hoping
# for feedback on how I can get this part to work, which is why 
# I left it in. Any help would be appretiated!



p "What is your genie's name?"
name = gets.chomp

p "What is your genie's age?"
age = gets.to_i

genie = Genie.new(name, age)

p genie

p "What is your wish?"
wish = gets.chomp

while granted = true
	p "What is your next wish?"
	wish = gets.chomp
end

p "Too many wishes!"
exit!





